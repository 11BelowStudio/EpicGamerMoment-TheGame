pls note: you will need to keep SuperSecretFiles folder in the same directory as the .jar, otherwise the score recording won't work!

Github repo: https://github.com/11BelowStudio/EpicGamerMoment-TheGame
itch.io page: https://11belowstudio.itch.io/EpicGamerMoment-TheGame

This game was made in 9 hours (between 6pm on 23/11/19 to 3am on 24/11/19) for a game jam hosted by the University of Essex Game Development Society.
The theme was 'A Day In The Life', in case you were wondering.

It runs on Java 8, so, if you have Java installed, it should work fine (or, at least, as fine as something like this can run).


**OKAY SO BASICALLY THESE ARE THE INSTRUCTIONS**

    You are an epic gamer, who must resist the urge to say The Gamer Word for as long as possible.

* WHAT YOU NEED TO DO*

    - Resist the urge to say The Gamer word

* HOW TO DO IT *

    - Balance your GamerCoins, GamerFuel, and GamerEnergy levels to resist the urge to say the Gamer Word.
    - When the urge to say the Gamer Word reaches 100, that's game over!

    - You can get GamerCoins by working
        but doing this costs GamerEnergy!
    - You can get GamerEnergy by eating GamerFuel
       but this consumes GamerFuel!
    - You can get GamerFuel by buying GamerFuel
        but this consumes GamerEnergy and GamerCoins!

    - You can resist the urge to say the Gamer Word by playing bideo game
       but this consumes GamerEnergy!

    - Alternatively you can just procrastinate, which consumes nothing, but gives you nothing.

    so yeah see how long you can last!

**CREDITS FOR 'EPIC GAMER MOMENT - THE GAME'**

    The image of Manny Heffley from 'Diary of a Wimpy Kid', as well as the speech bubble which were used albeit in an edited form in 'oof.png': Jeff Kinney

    Help with getting the images into the JAR file: jberg on Stack Overflow https://stackoverflow.com/a/5485186

    Everything else: 11BelowStudio

**PROGRAMS USED**

    Microsoft Paint
    IntelliJ IDEA 2019.2 (64-bit)

**SOME OTHER ASSORTED THOUGHTS OR SOMETHING LIKE THAT**

    yes I know this game sucks, why did I spend about nine hours working on this smh my head

    and yeah the code quality got really bad towards the end of the development, oh well

    and uhh yeah have fun (if that is, in fact, possible) bye
